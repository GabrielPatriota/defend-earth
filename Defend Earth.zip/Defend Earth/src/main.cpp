#include "window.hpp"

CreateWindow window;

int main()
{
    printf("running\n");
}